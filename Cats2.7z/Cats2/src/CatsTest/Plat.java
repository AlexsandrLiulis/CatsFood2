package CatsTest;

public class Plat {
    public static double SizePlat = 10;
}
