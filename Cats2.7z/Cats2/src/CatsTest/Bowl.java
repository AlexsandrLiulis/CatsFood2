package CatsTest;

public class Bowl {
    public static double SizeBowl = 20;
}
