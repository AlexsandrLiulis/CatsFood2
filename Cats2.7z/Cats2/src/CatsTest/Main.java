package CatsTest;

public class Main {
    public static void main(String[] args) {
        int CatSize = 10;

        Cat[] cats = new Cat[CatSize];
        for (int i = 0; i < cats.length; i++) {
            cats[i] = new Cat();
            cats[i].setName(i + 1);
        }
        System.out.println("Колличество кошек " + Cat.count);
        System.out.println("Колличество молока " + Plat.SizePlat + " литров");
        System.out.println("Колличество корма " + Bowl.SizeBowl + " кг\n");

        double catsMilk = Plat.SizePlat / CatSize;
        double catsFood = Bowl.SizeBowl / CatSize;

        for (int i = 0; i < cats.length; i++) {
            System.out.println(cats[i].getName() + " кошка пьёт молоко");
            Plat.SizePlat -= catsMilk;
            if (Plat.SizePlat > 0) {
                System.out.println("Осталось " + Plat.SizePlat + " л. молока");
            } else {
                System.out.println("Больше молока нет");
            }
            System.out.println(" ");
        }

        for (int i = 0; i < cats.length; i++) {
            System.out.println(cats[i].getName() + " кошка ест корм");
            Bowl.SizeBowl -= catsFood;
            if (Bowl.SizeBowl > 0) {
                System.out.println("Осталось " + Bowl.SizeBowl + " кг");
            } else {
                System.out.println("Больше корма нет");
            }
            System.out.println(" ");
        }
    }
}
