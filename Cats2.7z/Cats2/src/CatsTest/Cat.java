package CatsTest;

public class Cat {
    public static int count = 0;

    public int Name;

    public Cat() {
        count++;
    }

    public int getName() {
        return Name;
    }

    public void setName(int name) {
        Name = name;
    }
}
